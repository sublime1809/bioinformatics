# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""Tests for dealing with storage of biopython objects in a relational db.
"""
from __future__ import print_function

import os
import platform
import unittest
import tempfile
import time

from Bio._py3k import StringIO
from Bio._py3k import zip
from Bio._py3k import basestring

# Hide annoying warnings from things like bonds in GenBank features,
# or PostgreSQL schema rules. TODO - test these warnings are raised!
import warnings
from Bio import BiopythonWarning

# local stuff
from Bio import MissingExternalDependencyError
from Bio.Seq import Seq, MutableSeq
from Bio.SeqFeature import SeqFeature
from Bio import Alphabet
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

from BioSQL import BioSeqDatabase
from BioSQL import BioSeq

from seq_tests_common import compare_record, compare_records

if __name__ == "__main__":
    raise RuntimeError("Call this via test_BioSQL_*.py not directly")

global DBDRIVER, DBTYPE, DBHOST, DBUSER, DBPASSWD, TESTDB, DBSCHEMA, SQL_FILE
global SYSTEM

SYSTEM = platform.system()

def temp_db_filename():
    # In memory SQLite does not work with current test structure since the tests
    # expect databases to be retained between individual tests.
    # TESTDB = ':memory:'
    # Instead, we use (if we can) /dev/shm
    try:
        h, test_db_fname = tempfile.mkstemp("_BioSQL.db", dir='/dev/shm')
    except OSError:
        # We can't use /dev/shm
        h, test_db_fname = tempfile.mkstemp("_BioSQL.db")
    os.close(h)
    return test_db_fname


def check_config(dbdriver, dbtype, dbhost, dbuser, dbpasswd, testdb):
    global DBDRIVER, DBTYPE, DBHOST, DBUSER, DBPASSWD, TESTDB, DBSCHEMA
    global SYSTEM, SQL_FILE
    DBDRIVER = dbdriver
    DBTYPE = dbtype
    DBHOST = dbhost
    DBUSER = dbuser
    DBPASSWD = dbpasswd
    TESTDB = testdb

    #Check the database driver is installed:
    if SYSTEM == "Java":
        try:
            if DBDRIVER in ["MySQLdb"]:
                import com.mysql.jdbc.Driver
            elif DBDRIVER in ["psycopg2"]:
                import org.postgresql.Driver
        except ImportError:
            message = "Install the JDBC driver for %s to use BioSQL " % DBTYPE
            raise MissingExternalDependencyError(message)
    else:
        try:
            __import__(DBDRIVER)
        except ImportError:
            message = "Install %s if you want to use %s with BioSQL " % (DBDRIVER, DBTYPE)
            raise MissingExternalDependencyError(message)

    try:
        if DBDRIVER in ["sqlite3"]:
            server = BioSeqDatabase.open_database(driver=DBDRIVER, db=TESTDB)
        else:
            server = BioSeqDatabase.open_database(driver=DBDRIVER,
                                                  user=DBUSER, passwd=DBPASSWD,
                                                  host=DBHOST)
        server.close()
        del server
    except Exception as e:
        message = "Connection failed, check settings if you plan to use BioSQL: %s" % str(e)
        raise MissingExternalDependencyError(message)

    DBSCHEMA = "biosqldb-" + DBTYPE + ".sql"
    SQL_FILE = os.path.join(os.getcwd(), "BioSQL", DBSCHEMA)

    if not os.path.isfile(SQL_FILE):
        message = "Missing SQL schema file: %s" % SQL_FILE
        raise MissingExternalDependencyError(message)


def _do_db_create():
    """Do the actual work of database creation. Relevant for MySQL and PostgreSQL
    """
    # first open a connection to create the database
    server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                          user = DBUSER, passwd = DBPASSWD,
                                          host = DBHOST)

    if DBDRIVER == "pgdb":
        # The pgdb postgres driver does not support autocommit, so here we
        # commit the current transaction so that 'drop database' query will
        # be outside a transaction block
        server.adaptor.cursor.execute("COMMIT")
    else:
        # Auto-commit: postgresql cannot drop database in a transaction
        try:
            server.adaptor.autocommit()
        except AttributeError:
            pass

    # drop anything in the database
    try:
        # with Postgres, can get errors about database still being used and
        # not able to be dropped. Wait briefly to be sure previous tests are
        # done with it.
        time.sleep(1)

        sql = r"DROP DATABASE " + TESTDB
        server.adaptor.cursor.execute(sql, ())
    except (server.module.OperationalError,
            server.module.Error,
            server.module.DatabaseError) as e:  # the database doesn't exist
        pass
    except (server.module.IntegrityError,
            server.module.ProgrammingError) as e:  # ditto--perhaps
        if str(e).find('database "%s" does not exist' % TESTDB) == -1:
            server.close()
            raise
    # create a new database
    sql = r"CREATE DATABASE " + TESTDB
    server.adaptor.execute(sql, ())
    server.close()


def create_database():
    """Delete any existing BioSQL test database, then (re)create an empty BioSQL database."""
    if DBDRIVER in ["sqlite3"]:
        global TESTDB
        if os.path.exists(TESTDB):
            try:
                os.remove(TESTDB)
            except:
                time.sleep(1)
                try:
                    os.remove(TESTDB)
                except:
                    # Seen this with PyPy 2.1 (and older) on Windows -
                    # which suggests an open handle still exists?
                    print("Could not remove %r" % TESTDB)
                    pass
        # Now pick a new filename - just in case there is a stale handle
        # (which might be happening under Windows...)
        TESTDB = temp_db_filename()
    else:
        _do_db_create()

    # now open a connection to load the database
    server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                          user = DBUSER, passwd = DBPASSWD,
                                          host = DBHOST, db = TESTDB)
    try:
        server.load_database_sql(SQL_FILE)
        server.commit()
        server.close()
    except:
        # Failed, but must close the handle...
        server.close()
        raise


def destroy_database():
    """Delete any temporary BioSQL sqlite3 database files."""
    if DBDRIVER in ["sqlite3"]:
        if os.path.exists(TESTDB):
            os.remove(TESTDB)


def load_database(gb_filename_or_handle):
    """Load a GenBank file into a new BioSQL database.

    This is useful for running tests against a newly created database.
    """

    create_database()
    # now open a connection to load the database
    db_name = "biosql-test"
    server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                          user = DBUSER, passwd = DBPASSWD,
                                          host = DBHOST, db = TESTDB)
    db = server.new_database(db_name)

    # get the GenBank file we are going to put into it
    iterator = SeqIO.parse(gb_filename_or_handle, "gb")
    # finally put it in the database
    count = db.load(iterator)
    server.commit()
    server.close()
    return count


class ReadTest(unittest.TestCase):
    """Test reading a database from an already built database.
    """
    loaded_db = 0

    def setUp(self):
        """Connect to and load up the database.
        """
        load_database("GenBank/cor6_6.gb")

        self.server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                                   user = DBUSER,
                                                   passwd = DBPASSWD,
                                                   host = DBHOST, db = TESTDB)

        self.db = self.server["biosql-test"]

    def tearDown(self):
        self.server.close()
        destroy_database()
        del self.db
        del self.server

    def test_server(self):
        """Check BioSeqDatabase methods"""
        server = self.server
        self.assertTrue("biosql-test" in server)
        self.assertEqual(1, len(server))
        self.assertEqual(["biosql-test"], list(server.keys()))
        #Check we can delete the namespace...
        del server["biosql-test"]
        self.assertEqual(0, len(server))
        try:
            del server["non-existant-name"]
            assert False, "Should have raised KeyError"
        except KeyError:
            pass

    def test_get_db_items(self):
        """Check list, keys, length etc"""
        db = self.db
        items = list(db.values())
        keys = list(db)
        l = len(items)
        self.assertEqual(l, len(db))
        self.assertEqual(l, len(list(db.items())))
        self.assertEqual(l, len(list(db)))
        self.assertEqual(l, len(list(db.values())))
        for (k1, r1), (k2, r2) in zip(zip(keys, items), db.items()):
            self.assertEqual(k1, k2)
            self.assertEqual(r1.id, r2.id)
        for k in keys:
            del db[k]
        self.assertEqual(0, len(db))
        try:
            del db["non-existant-name"]
            assert False, "Should have raised KeyError"
        except KeyError:
            pass

    def test_lookup_items(self):
        """Test retrieval of items using various ids.
        """
        self.db.lookup(accession = "X62281")
        try:
            self.db.lookup(accession = "Not real")
            raise AssertionError("No problem on fake id retrieval")
        except IndexError:
            pass
        self.db.lookup(display_id = "ATKIN2")
        try:
            self.db.lookup(display_id = "Not real")
            raise AssertionError("No problem on fake id retrieval")
        except IndexError:
            pass

        # primary id retrieval
        self.db.lookup(primary_id = "16353")
        try:
            self.db.lookup(primary_id = "Not Real")
            raise AssertionError("No problem on fake primary id retrieval")
        except IndexError:
            pass


class SeqInterfaceTest(unittest.TestCase):
    """Make sure the BioSQL objects implement the expected biopython interfaces
    """
    def setUp(self):
        """Load a database.
        """
        load_database("GenBank/cor6_6.gb")

        self.server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                                   user = DBUSER, passwd = DBPASSWD,
                                                   host = DBHOST, db = TESTDB)
        self.db = self.server["biosql-test"]
        self.item = self.db.lookup(accession = "X62281")

    def tearDown(self):
        self.server.close()
        destroy_database()
        del self.db
        del self.item
        del self.server

    def test_seq_record(self):
        """Make sure SeqRecords from BioSQL implement the right interface.
        """
        test_record = self.item
        self.assertTrue(isinstance(test_record.seq, BioSeq.DBSeq))
        self.assertEqual(test_record.id, "X62281.1", test_record.id)
        self.assertEqual(test_record.name, "ATKIN2")
        self.assertEqual(test_record.description, "A.thaliana kin2 gene.")
        self.assertTrue(hasattr(test_record, 'annotations'))
        # XXX should do something with annotations once they are like
        # a dictionary
        for feature in test_record.features:
            self.assertTrue(isinstance(feature, SeqFeature))
        self.assertTrue(isinstance(str(test_record), basestring))  # shouldn't cause any errors!

    def test_seq(self):
        """Make sure Seqs from BioSQL implement the right interface.
        """
        test_seq = self.item.seq
        alphabet = test_seq.alphabet
        self.assertTrue(isinstance(alphabet, Alphabet.Alphabet))
        data = test_seq.data
        self.assertEqual(type(data), type(""))
        string_rep = str(test_seq)
        self.assertEqual(string_rep, str(test_seq))  # check __str__ too
        self.assertEqual(type(string_rep), type(""))
        self.assertEqual(len(test_seq), 880)

    def test_convert(self):
        """Check can turn a DBSeq object into a Seq or MutableSeq."""
        test_seq = self.item.seq

        other = test_seq.toseq()
        self.assertEqual(str(test_seq), str(other))
        self.assertEqual(test_seq.alphabet, other.alphabet)
        self.assertTrue(isinstance(other, Seq))

        other = test_seq.tomutable()
        self.assertEqual(str(test_seq), str(other))
        self.assertEqual(test_seq.alphabet, other.alphabet)
        self.assertTrue(isinstance(other, MutableSeq))

    def test_addition(self):
        """Check can add DBSeq objects together."""
        test_seq = self.item.seq
        for other in [Seq("ACGT", test_seq.alphabet),
                      MutableSeq("ACGT", test_seq.alphabet),
                      "ACGT",
                      test_seq]:
            test = test_seq + other
            self.assertEqual(str(test), str(test_seq) + str(other))
            self.assertTrue(isinstance(test, Seq))
            test = other + test_seq
            self.assertEqual(str(test), str(other) + str(test_seq))

    def test_seq_slicing(self):
        """Check that slices of sequences are retrieved properly.
        """
        test_seq = self.item.seq
        new_seq = test_seq[:10]
        self.assertTrue(isinstance(new_seq, BioSeq.DBSeq))
        # simple slicing
        self.assertEqual(str(test_seq[:5]), 'ATTTG')
        self.assertEqual(str(test_seq[0:5]), 'ATTTG')
        self.assertEqual(str(test_seq[2:3]), 'T')
        self.assertEqual(str(test_seq[2:4]), 'TT')
        self.assertEqual(str(test_seq[870:]), 'TTGAATTATA')
        # getting more fancy
        self.assertEqual(test_seq[-1], 'A')
        self.assertEqual(test_seq[1], 'T')
        self.assertEqual(str(test_seq[-10:][5:]), "TTATA")
        self.assertEqual(str(test_seq[-10:][5:]), "TTATA")

    def test_seq_features(self):
        """Check SeqFeatures of a sequence.
        """
        test_features = self.item.features
        cds_feature = test_features[6]
        self.assertEqual(cds_feature.type, "CDS")
        self.assertEqual(str(cds_feature.location), "join{[103:160](+), [319:390](+), [503:579](+)}")
        for sub_feature in cds_feature._sub_features:
            self.assertEqual(sub_feature.type, "CDS")
            #self.assertEqual(sub_feature.location_operator, "join")

        try:
            self.assertEqual(cds_feature.qualifiers["gene"], ["kin2"])
            self.assertEqual(cds_feature.qualifiers["protein_id"], ["CAA44171.1"])
            self.assertEqual(cds_feature.qualifiers["codon_start"], ["1"])
        except KeyError:
            raise KeyError("Missing expected entries, have %s"
                           % repr(cds_feature.qualifiers))

        self.assertTrue("db_xref" in cds_feature.qualifiers)
        multi_ann = cds_feature.qualifiers["db_xref"]
        self.assertEqual(len(multi_ann), 2)
        self.assertTrue("GI:16354" in multi_ann)
        self.assertTrue("SWISS-PROT:P31169" in multi_ann)


class LoaderTest(unittest.TestCase):
    """Load a database from a GenBank file.
    """
    def setUp(self):
        # create TESTDB
        create_database()

        # load the database
        db_name = "biosql-test"
        self.server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                                   user = DBUSER, passwd = DBPASSWD,
                                                   host = DBHOST, db = TESTDB)

        # remove the database if it already exists
        try:
            self.server[db_name]
            self.server.remove_database(db_name)
        except KeyError:
            pass

        self.db = self.server.new_database(db_name)

        # get the GenBank file we are going to put into it
        self.iterator = SeqIO.parse("GenBank/cor6_6.gb", "gb")

    def tearDown(self):
        self.server.close()
        destroy_database()
        del self.db
        del self.server

    def test_load_database(self):
        """Load SeqRecord objects into a BioSQL database.
        """
        self.db.load(self.iterator)

        # do some simple tests to make sure we actually loaded the right
        # thing. More advanced tests in a different module.
        items = list(self.db.values())
        self.assertEqual(len(items), 6)
        self.assertEqual(len(self.db), 6)
        item_names = []
        item_ids = []
        for item in items:
            item_names.append(item.name)
            item_ids.append(item.id)
        item_names.sort()
        item_ids.sort()
        self.assertEqual(item_names, ['AF297471', 'ARU237582', 'ATCOR66M',
                                      'ATKIN2', 'BNAKINI', 'BRRBIF72'])
        self.assertEqual(item_ids, ['AF297471.1', 'AJ237582.1', 'L31939.1',
                                    'M81224.1', 'X55053.1', 'X62281.1'])


class DupLoadTest(unittest.TestCase):
    """Check a few duplicate conditions fail."""
    def setUp(self):
        #drop any old database and create a new one:
        create_database()
        #connect to new database:
        self.server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                                   user = DBUSER, passwd = DBPASSWD,
                                                   host = DBHOST, db = TESTDB)
        #Create new namespace within new empty database:
        self.db = self.server.new_database("biosql-test")

    def tearDown(self):
        self.server.rollback()
        self.server.close()
        destroy_database()
        del self.db
        del self.server

    def test_duplicate_load(self):
        """Make sure can't import a single record twice (in one go)."""
        record = SeqRecord(Seq("ATGCTATGACTAT", Alphabet.generic_dna), id="Test1")
        try:
            count = self.db.load([record, record])
        except Exception as err:
            #Good!
            #Note we don't do a specific exception handler because the
            #exception class will depend on which DB back end is in use.
            self.assertTrue(err.__class__.__name__ in ["IntegrityError",
                                                       "AttributeError",
                                                       "OperationalError"],
                            err.__class__.__name__)
            return
        raise Exception("Should have failed! Loaded %i records" % count)

    def test_duplicate_load2(self):
        """Make sure can't import a single record twice (in steps)."""
        record = SeqRecord(Seq("ATGCTATGACTAT", Alphabet.generic_dna), id="Test2")
        count = self.db.load([record])
        self.assertEqual(count, 1)
        try:
            count = self.db.load([record])
        except Exception as err:
            #Good!
            self.assertTrue(err.__class__.__name__ in ["IntegrityError",
                                                       "AttributeError"],
                            err.__class__.__name__)
            return
        raise Exception("Should have failed! Loaded %i records" % count)

    def test_duplicate_id_load(self):
        """Make sure can't import records with same ID (in one go)."""
        record1 = SeqRecord(Seq("ATGCTATGACTAT", Alphabet.generic_dna), id="TestA")
        record2 = SeqRecord(Seq("GGGATGCGACTAT", Alphabet.generic_dna), id="TestA")
        try:
            count = self.db.load([record1, record2])
        except Exception as err:
            #Good!
            self.assertTrue(err.__class__.__name__ in ["IntegrityError",
                                                       "AttributeError"],
                            err.__class__.__name__)
            return
        raise Exception("Should have failed! Loaded %i records" % count)


class ClosedLoopTest(unittest.TestCase):
    """Test file -> BioSQL -> file."""
    #NOTE - For speed I don't bother to create a new database each time,
    #simple a new unique namespace is used for each test.

    def test_NC_005816(self):
        """GenBank file to BioSQL and back to a GenBank file, NC_005816."""
        self.loop("GenBank/NC_005816.gb", "gb")

    def test_NC_000932(self):
        """GenBank file to BioSQL and back to a GenBank file, NC_000932."""
        self.loop("GenBank/NC_000932.gb", "gb")

    def test_NT_019265(self):
        """GenBank file to BioSQL and back to a GenBank file, NT_019265."""
        self.loop("GenBank/NT_019265.gb", "gb")

    def test_protein_refseq2(self):
        """GenBank file to BioSQL and back to a GenBank file, protein_refseq2."""
        self.loop("GenBank/protein_refseq2.gb", "gb")

    def test_no_ref(self):
        """GenBank file to BioSQL and back to a GenBank file, noref."""
        self.loop("GenBank/noref.gb", "gb")

    def test_one_of(self):
        """GenBank file to BioSQL and back to a GenBank file, one_of."""
        self.loop("GenBank/one_of.gb", "gb")

    def test_cor6_6(self):
        """GenBank file to BioSQL and back to a GenBank file, cor6_6."""
        self.loop("GenBank/cor6_6.gb", "gb")

    def test_arab1(self):
        """GenBank file to BioSQL and back to a GenBank file, arab1."""
        self.loop("GenBank/arab1.gb", "gb")

    def loop(self, filename, format):
        original_records = list(SeqIO.parse(filename, format))
        # now open a connection to load the database
        server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                              user = DBUSER, passwd = DBPASSWD,
                                              host = DBHOST, db = TESTDB)
        db_name = "test_loop_%s" % filename  # new namespace!
        db = server.new_database(db_name)
        count = db.load(original_records)
        self.assertEqual(count, len(original_records))
        server.commit()
        #Now read them back...
        biosql_records = [db.lookup(name=rec.name)
                          for rec in original_records]
        #And check they agree
        self.assertTrue(compare_records(original_records, biosql_records))
        #Now write to a handle...
        handle = StringIO()
        SeqIO.write(biosql_records, handle, "gb")
        #Now read them back...
        handle.seek(0)
        new_records = list(SeqIO.parse(handle, "gb"))
        #And check they still agree
        self.assertEqual(len(new_records), len(original_records))
        for old, new in zip(original_records, new_records):
            #TODO - remove this hack because we don't yet write these (yet):
            for key in ["comment", "references", "db_source"]:
                if key in old.annotations and key not in new.annotations:
                    del old.annotations[key]
            self.assertTrue(compare_record(old, new))
        #Done
        handle.close()
        server.close()


class TransferTest(unittest.TestCase):
    """Test file -> BioSQL, BioSQL -> BioSQL."""
    #NOTE - For speed I don't bother to create a new database each time,
    #simple a new unique namespace is used for each test.

    def setUp(self):
        create_database()

    def test_NC_005816(self):
        """GenBank file to BioSQL, then again to a new namespace, NC_005816."""
        self.trans("GenBank/NC_005816.gb", "gb")

    def test_NC_000932(self):
        """GenBank file to BioSQL, then again to a new namespace, NC_000932."""
        self.trans("GenBank/NC_000932.gb", "gb")

    def test_NT_019265(self):
        """GenBank file to BioSQL, then again to a new namespace, NT_019265."""
        self.trans("GenBank/NT_019265.gb", "gb")

    def test_protein_refseq2(self):
        """GenBank file to BioSQL, then again to a new namespace, protein_refseq2."""
        self.trans("GenBank/protein_refseq2.gb", "gb")

    def test_no_ref(self):
        """GenBank file to BioSQL, then again to a new namespace, noref."""
        self.trans("GenBank/noref.gb", "gb")

    def test_one_of(self):
        """GenBank file to BioSQL, then again to a new namespace, one_of."""
        self.trans("GenBank/one_of.gb", "gb")

    def test_cor6_6(self):
        """GenBank file to BioSQL, then again to a new namespace, cor6_6."""
        self.trans("GenBank/cor6_6.gb", "gb")

    def test_arab1(self):
        """GenBank file to BioSQL, then again to a new namespace, arab1."""
        self.trans("GenBank/arab1.gb", "gb")

    def trans(self, filename, format):
        original_records = list(SeqIO.parse(filename, format))
        # now open a connection to load the database
        server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                              user = DBUSER, passwd = DBPASSWD,
                                              host = DBHOST, db = TESTDB)
        db_name = "test_trans1_%s" % filename  # new namespace!
        db = server.new_database(db_name)
        count = db.load(original_records)
        self.assertEqual(count, len(original_records))
        server.commit()
        #Now read them back...
        biosql_records = [db.lookup(name=rec.name)
                          for rec in original_records]
        #And check they agree
        self.assertTrue(compare_records(original_records, biosql_records))
        #Now write to a second name space...
        db_name = "test_trans2_%s" % filename  # new namespace!
        db = server.new_database(db_name)
        count = db.load(biosql_records)
        self.assertEqual(count, len(original_records))
        #Now read them back again,
        biosql_records2 = [db.lookup(name=rec.name)
                           for rec in original_records]
        #And check they also agree
        self.assertTrue(compare_records(original_records, biosql_records2))
        #Done
        server.close()

    def tearDown(self):
        destroy_database()


class InDepthLoadTest(unittest.TestCase):
    """Make sure we are loading and retreiving in a semi-lossless fashion.
    """
    def setUp(self):
        gb_file = os.path.join(os.getcwd(), "GenBank", "cor6_6.gb")
        load_database(gb_file)

        self.server = BioSeqDatabase.open_database(driver = DBDRIVER,
                                                   user = DBUSER, passwd = DBPASSWD,
                                                   host = DBHOST, db = TESTDB)
        self.db = self.server["biosql-test"]

    def tearDown(self):
        self.server.close()
        destroy_database()
        del self.db
        del self.server

    def test_transfer(self):
        """Make sure can load record into another namespace."""
        #Should be in database already...
        db_record = self.db.lookup(accession = "X55053")
        #Make a new namespace
        db2 = self.server.new_database("biosql-test-alt")
        #Should be able to load this DBSeqRecord there...
        count = db2.load([db_record])
        self.assertEqual(count, 1)

    def test_reload(self):
        """Make sure can't reimport existing records."""
        gb_file = os.path.join(os.getcwd(), "GenBank", "cor6_6.gb")
        gb_handle = open(gb_file, "r")
        record = next(SeqIO.parse(gb_handle, "gb"))
        gb_handle.close()
        #Should be in database already...
        db_record = self.db.lookup(accession = "X55053")
        self.assertEqual(db_record.id, record.id)
        self.assertEqual(db_record.name, record.name)
        self.assertEqual(db_record.description, record.description)
        self.assertEqual(str(db_record.seq), str(record.seq))
        #Good... now try reloading it!
        try:
            count = self.db.load([record])
        except Exception as err:
            #Good!
            self.assertTrue(err.__class__.__name__ in ["IntegrityError",
                                                       "AttributeError"],
                            err.__class__.__name__)
            return
        raise Exception("Should have failed! Loaded %i records" % count)

    def test_record_loading(self):
        """Make sure all records are correctly loaded.
        """
        test_record = self.db.lookup(accession = "X55053")
        self.assertEqual(test_record.name, "ATCOR66M")
        self.assertEqual(test_record.id, "X55053.1")
        self.assertEqual(test_record.description, "A.thaliana cor6.6 mRNA.")
        self.assertTrue(isinstance(test_record.seq.alphabet, Alphabet.DNAAlphabet))
        self.assertEqual(str(test_record.seq[:10]), 'AACAAAACAC')

        test_record = self.db.lookup(accession = "X62281")
        self.assertEqual(test_record.name, "ATKIN2")
        self.assertEqual(test_record.id, "X62281.1")
        self.assertEqual(test_record.description, "A.thaliana kin2 gene.")
        self.assertTrue(isinstance(test_record.seq.alphabet, Alphabet.DNAAlphabet))
        self.assertEqual(str(test_record.seq[:10]), 'ATTTGGCCTA')

    def test_seq_feature(self):
        """In depth check that SeqFeatures are transmitted through the db.
        """
        test_record = self.db.lookup(accession = "AJ237582")
        features = test_record.features
        self.assertEqual(len(features), 7)

        # test single locations
        test_feature = features[0]
        self.assertEqual(test_feature.type, "source")
        self.assertEqual(str(test_feature.location), "[0:206](+)")
        self.assertEqual(len(test_feature.qualifiers), 3)
        self.assertEqual(test_feature.qualifiers["country"], ["Russia:Bashkortostan"])
        self.assertEqual(test_feature.qualifiers["organism"], ["Armoracia rusticana"])
        self.assertEqual(test_feature.qualifiers["db_xref"], ["taxon:3704"])

        # test split locations
        test_feature = features[4]
        self.assertEqual(test_feature.type, "CDS")
        self.assertEqual(str(test_feature.location), "join{[0:48](+), [142:206](+)}")
        self.assertEqual(len(test_feature._sub_features), 2)
        self.assertEqual(str(test_feature._sub_features[0].location), "[0:48](+)")
        self.assertEqual(test_feature._sub_features[0].type, "CDS")
        #self.assertEqual(test_feature._sub_features[0].location_operator, "join")
        self.assertEqual(str(test_feature._sub_features[1].location), "[142:206](+)")
        self.assertEqual(test_feature._sub_features[1].type, "CDS")
        #self.assertEqual(test_feature._sub_features[1].location_operator, "join")
        self.assertEqual(len(test_feature.qualifiers), 6)
        self.assertEqual(test_feature.qualifiers["gene"], ["csp14"])
        self.assertEqual(test_feature.qualifiers["codon_start"], ["2"])
        self.assertEqual(test_feature.qualifiers["product"],
                         ["cold shock protein"])
        self.assertEqual(test_feature.qualifiers["protein_id"], ["CAB39890.1"])
        self.assertEqual(test_feature.qualifiers["db_xref"], ["GI:4538893"])
        self.assertEqual(test_feature.qualifiers["translation"],
                         ["DKAKDAAAAAGASAQQAGKNISDAAAGGVNFVKEKTG"])

        # test passing strand information
        # XXX We should be testing complement as well
        test_record = self.db.lookup(accession = "AJ237582")
        test_feature = test_record.features[4]  # DNA, no complement
        self.assertEqual(test_feature.strand, 1)
        for sub_feature in test_feature._sub_features:
            self.assertEqual(sub_feature.strand, 1)

        test_record = self.db.lookup(accession = "X55053")
        test_feature = test_record.features[0]
        # mRNA, so really cDNA, so the strand should be 1 (not complemented)
        self.assertEqual(test_feature.strand, 1)


#####################################################################

class AutoSeqIOTests(unittest.TestCase):
    """Test SeqIO and BioSQL together."""
    server = None
    db = None

    def setUp(self):
        """Connect to the database."""
        db_name = "biosql-test-seqio"
        server = BioSeqDatabase.open_database(driver=DBDRIVER,
                                              user=DBUSER,
                                              passwd=DBPASSWD,
                                              host=DBHOST, db=TESTDB)
        self.server = server
        if db_name not in server:
            self.db = server.new_database(db_name)
            server.commit()
        self.db = self.server[db_name]

    def tearDown(self):
        if self.db:
            del self.db
        if self.server:
            self.server.close()
            del self.server

    def check(self, t_format, t_filename, t_count=1):
        db = self.db

        iterator = SeqIO.parse(t_filename, t_format)
        count = db.load(iterator)
        assert count == t_count
        self.server.commit()

        iterator = SeqIO.parse(t_filename, t_format)
        for record in iterator:
            #print(" - %s, %s" % (checksum_summary(record), record.id))
            key = record.name
            #print(" - Retrieving by name/display_id '%s'," % key)
            db_rec = db.lookup(name=key)
            compare_record(record, db_rec)
            db_rec = db.lookup(display_id=key)
            compare_record(record, db_rec)

            key = record.id
            if key.count(".") == 1 and key.split(".")[1].isdigit():
                #print(" - Retrieving by version '%s'," % key)
                db_rec = db.lookup(version=key)
                compare_record(record, db_rec)

            if "accessions" in record.annotations:
                #Only expect FIRST accession to work!
                key = record.annotations["accessions"][0]
                assert key, "Blank accession in annotation %s" % repr(record.annotations)
                if key != record.id:
                    #print(" - Retrieving by accession '%s'," % key)
                    db_rec = db.lookup(accession=key)
                    compare_record(record, db_rec)

            if "gi" in record.annotations:
                key = record.annotations['gi']
                if key != record.id:
                    #print(" - Retrieving by GI '%s'," % key)
                    db_rec = db.lookup(primary_id=key)
                    compare_record(record, db_rec)

    def test_SeqIO_loading(self):
        self.check('fasta', 'Fasta/lupine.nu')
        self.check('fasta', 'Fasta/elderberry.nu')
        self.check('fasta', 'Fasta/phlox.nu')
        self.check('fasta', 'Fasta/centaurea.nu')
        self.check('fasta', 'Fasta/wisteria.nu')
        self.check('fasta', 'Fasta/sweetpea.nu')
        self.check('fasta', 'Fasta/lavender.nu')
        self.check('fasta', 'Fasta/aster.pro')
        self.check('fasta', 'Fasta/loveliesbleeding.pro')
        self.check('fasta', 'Fasta/rose.pro')
        self.check('fasta', 'Fasta/rosemary.pro')
        self.check('fasta', 'Fasta/f001')
        self.check('fasta', 'Fasta/f002', 3)
        self.check('fasta', 'Fasta/fa01', 2)
        self.check('fasta', 'GFF/NC_001802.fna')
        self.check('fasta', 'GFF/multi.fna', 3)
        self.check('fasta', 'Registry/seqs.fasta', 2)
        self.check('swiss', 'SwissProt/sp001')
        self.check('swiss', 'SwissProt/sp002')
        self.check('swiss', 'SwissProt/sp003')
        self.check('swiss', 'SwissProt/sp004')
        self.check('swiss', 'SwissProt/sp005')
        self.check('swiss', 'SwissProt/sp006')
        self.check('swiss', 'SwissProt/sp007')
        self.check('swiss', 'SwissProt/sp008')
        self.check('swiss', 'SwissProt/sp009')
        self.check('swiss', 'SwissProt/sp010')
        self.check('swiss', 'SwissProt/sp011')
        self.check('swiss', 'SwissProt/sp012')
        self.check('swiss', 'SwissProt/sp013')
        self.check('swiss', 'SwissProt/sp014')
        self.check('swiss', 'SwissProt/sp015')
        self.check('swiss', 'SwissProt/sp016')
        self.check('swiss', 'Registry/EDD_RAT.dat')
        self.check('genbank', 'GenBank/noref.gb')
        self.check('genbank', 'GenBank/cor6_6.gb', 6)
        self.check('genbank', 'GenBank/iro.gb')
        self.check('genbank', 'GenBank/pri1.gb')
        self.check('genbank', 'GenBank/arab1.gb')
        with warnings.catch_warnings():
            #BiopythonWarning: order location operators are not fully supported
            warnings.simplefilter("ignore", BiopythonWarning)
            self.check('genbank', 'GenBank/protein_refseq2.gb')
        self.check('genbank', 'GenBank/extra_keywords.gb')
        self.check('genbank', 'GenBank/one_of.gb')
        self.check('genbank', 'GenBank/NT_019265.gb')
        self.check('genbank', 'GenBank/origin_line.gb')
        self.check('genbank', 'GenBank/blank_seq.gb')
        with warnings.catch_warnings():
            #BiopythonWarning: bond location operators are not fully supported
            warnings.simplefilter("ignore", BiopythonWarning)
            self.check('genbank', 'GenBank/dbsource_wrap.gb')
        self.check('genbank', 'GenBank/NC_005816.gb')
        self.check('genbank', 'GenBank/gbvrl1_start.seq', 3)
        self.check('genbank', 'GFF/NC_001422.gbk')
        self.check('embl', 'EMBL/TRBG361.embl')
        self.check('embl', 'EMBL/DD231055_edited.embl')
        self.check('embl', 'EMBL/SC10H5.embl')
        self.check('embl', 'EMBL/U87107.embl')
        self.assertEqual(len(self.db), 66)
