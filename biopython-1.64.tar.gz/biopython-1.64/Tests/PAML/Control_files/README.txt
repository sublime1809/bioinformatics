This folder contains the resources necessary to generate the PAML test result files.
